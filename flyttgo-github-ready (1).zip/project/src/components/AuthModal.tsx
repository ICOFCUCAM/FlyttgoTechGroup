// AuthModal — placeholder stub
// Replace this with your original AuthModal.tsx from the new-files batch.
import React from 'react';
import { useApp } from '../lib/store';

export default function AuthModal() {
  const { setPage } = useApp();
  return (
    <div className="min-h-[60vh] flex items-center justify-center bg-gray-50">
      <div className="text-center p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-2">AuthModal</h2>
        <p className="text-gray-500 text-sm">Replace src/components/AuthModal.tsx with your original file.</p>
        <button onClick={() => setPage('home')} className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm">Home</button>
      </div>
    </div>
  );
}
