import React, { lazy, Suspense } from 'react';
import { useApp } from '../lib/store';
import { useAuth } from '../lib/auth';
import Header from './Header';
import Footer from './Footer';
import AuthModal from './AuthModal';

// Core pages (eager)
import HomePage from './HomePage';

// Lazy-loaded feature pages
const BookingFlow         = lazy(() => import('./BookingFlow'));
const SubscriptionPlans   = lazy(() => import('./SubscriptionPlans'));
const CustomerDashboard   = lazy(() => import('./CustomerDashboard'));
const MyBookings          = lazy(() => import('./MyBookings'));
const DriverPortal        = lazy(() => import('./DriverPortal'));
const DriverOnboarding    = lazy(() => import('./DriverOnboarding'));
const AdminDashboard      = lazy(() => import('./AdminDashboard'));
const VanGuide            = lazy(() => import('./VanGuide'));
const MovingChecklist     = lazy(() => import('./MovingChecklist'));

// Legal pages (lazy)
const TermsPage           = lazy(() => import('../pages/TermsPage'));
const PrivacyPage         = lazy(() => import('../pages/PrivacyPage'));
const LiabilityPage       = lazy(() => import('../pages/LiabilityPage'));
const DriverTermsPage     = lazy(() => import('../pages/DriverTermsPage'));

/* ================= ERROR BOUNDARY ================= */

class ErrorBoundary extends React.Component<{ name: string; children: React.ReactNode }, { error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error: any) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-8">
          <div className="bg-white rounded-xl border border-red-200 p-8 max-w-lg w-full">
            <h2 className="text-xl font-bold text-red-600 mb-2">Error in: {this.props.name}</h2>
            <p className="text-gray-700 font-mono text-sm bg-red-50 p-4 rounded">
              {this.state.error.message}
            </p>
            <button
              onClick={() => this.setState({ error: null })}
              className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded"
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

/* ================= PAGE LOADER ================= */

const PageLoader = () => (
  <div className="min-h-screen bg-gray-50 flex items-center justify-center">
    <div className="w-10 h-10 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
  </div>
);

const Wrap = ({ name, children }: { name: string; children: React.ReactNode }) => (
  <ErrorBoundary name={name}>
    <Suspense fallback={<PageLoader />}>
      {children}
    </Suspense>
  </ErrorBoundary>
);

/* ================= APP LAYOUT ================= */

export default function AppLayout() {
  const { currentPage } = useApp();
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500 font-medium">Loading FlyttGo...</p>
        </div>
      </div>
    );
  }

  const isAdminPage = currentPage === 'admin';
  const isLegalPage = ['terms', 'privacy', 'liability', 'driver-terms'].includes(currentPage);

  const renderPage = () => {
    switch (currentPage) {
      // Main pages
      case 'home':
        return <ErrorBoundary name="HomePage"><HomePage /></ErrorBoundary>;
      case 'booking':
        return <Wrap name="BookingFlow"><BookingFlow /></Wrap>;
      case 'subscriptions':
        return <Wrap name="SubscriptionPlans"><SubscriptionPlans /></Wrap>;
      case 'customer-dashboard':
        return <Wrap name="CustomerDashboard"><CustomerDashboard /></Wrap>;
      case 'my-bookings':
        return <Wrap name="MyBookings"><MyBookings /></Wrap>;
      case 'driver-portal':
        return <Wrap name="DriverPortal"><DriverPortal /></Wrap>;
      case 'driver-onboarding':
        return <Wrap name="DriverOnboarding"><DriverOnboarding /></Wrap>;
      case 'admin':
        return <Wrap name="AdminDashboard"><AdminDashboard /></Wrap>;
      case 'van-guide':
        return <Wrap name="VanGuide"><VanGuide /></Wrap>;
      case 'checklist':
        return <Wrap name="MovingChecklist"><MovingChecklist /></Wrap>;

      // Legal pages
      case 'terms':
        return <Wrap name="TermsPage"><TermsPage /></Wrap>;
      case 'privacy':
        return <Wrap name="PrivacyPage"><PrivacyPage /></Wrap>;
      case 'liability':
        return <Wrap name="LiabilityPage"><LiabilityPage /></Wrap>;
      case 'driver-terms':
        return <Wrap name="DriverTermsPage"><DriverTermsPage /></Wrap>;

      default:
        return <ErrorBoundary name="HomePage"><HomePage /></ErrorBoundary>;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <AuthModal />
      {!isAdminPage && <Header />}
      <main className="flex-1">
        {renderPage()}
      </main>
      {!isAdminPage && <Footer />}
    </div>
  );
}
