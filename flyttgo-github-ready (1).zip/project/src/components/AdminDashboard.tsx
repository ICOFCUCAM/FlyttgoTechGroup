// AdminDashboard — placeholder
// Replace this file with the original AdminDashboard.tsx from your new-files batch.
// It was received in session 2 and is too large to include here.
// The component imports: useAuth, useApp, supabase, and all shadcn/ui components.

import React from 'react';
import { useAuth } from '../lib/auth';
import { useApp } from '../lib/store';

export default function AdminDashboard() {
  const { profile } = useAuth();
  const { setPage } = useApp();

  if (!profile || profile.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white rounded-2xl p-10 text-center border shadow-sm max-w-md">
          <h2 className="text-xl font-bold text-gray-900 mb-2">Admin Access Required</h2>
          <p className="text-gray-500 text-sm mb-6">You need admin credentials to access this page.</p>
          <button onClick={() => setPage('home')} className="px-6 py-3 bg-[#0B2E59] text-white rounded-xl font-semibold">
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-4">Admin Dashboard</h1>
      <p className="text-gray-500">Replace this file with your full AdminDashboard.tsx component.</p>
    </div>
  );
}
