// MyBookings — placeholder stub
// Replace this with your original MyBookings.tsx from the new-files batch.
import React from 'react';
import { useApp } from '../lib/store';

export default function MyBookings() {
  const { setPage } = useApp();
  return (
    <div className="min-h-[60vh] flex items-center justify-center bg-gray-50">
      <div className="text-center p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-2">MyBookings</h2>
        <p className="text-gray-500 text-sm">Replace src/components/MyBookings.tsx with your original file.</p>
        <button onClick={() => setPage('home')} className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm">Home</button>
      </div>
    </div>
  );
}
