// FlyttGo v1.1
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.tsx'
import './index.css'

// Global patch — makes .toFixed() safe on NaN/Infinity (prevents crashes in price calculations)
const _origToFixed = Number.prototype.toFixed;
Number.prototype.toFixed = function (digits?: number) {
  if (isNaN(this.valueOf()) || !isFinite(this.valueOf())) return '0';
  return _origToFixed.call(this, digits);
};

createRoot(document.getElementById('root')!).render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);
