// src/pages/Index.tsx
// The homepage is now served through AppLayout via the store's currentPage system.
// This file exists for React Router compatibility — the "/" route renders AppLayout
// which defaults to showing HomePage when currentPage === 'home'.
import AppLayout from '@/components/AppLayout';

const Index = () => <AppLayout />;

export default Index;
