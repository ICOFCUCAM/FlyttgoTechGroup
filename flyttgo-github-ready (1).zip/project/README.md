# FlyttGo — Norwegian Moving & Logistics Marketplace

A production-grade marketplace connecting customers with independent transport providers across Norway.

**Stack:** React 18 · TypeScript · Vite · Tailwind CSS · shadcn/ui · Supabase · Stripe · Vipps

---

## Quick Start

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/flyttgo.git
cd flyttgo
npm install
```

### 2. Set up environment variables

```bash
cp .env.example .env.local
```

Edit `.env.local` and fill in:

```env
VITE_SUPABASE_URL=https://jomhtghowrtegjfddite.databasepad.com
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key_here
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_key_here
```

### 3. Add your large component files

The following components are too large to auto-generate and must be copied from your original new-files batch:

| File | Source |
|------|--------|
| `src/components/AdminDashboard.tsx` | new-files batch |
| `src/components/AuthModal.tsx` | new-files batch |
| `src/components/CustomerDashboard.tsx` | new-files batch |
| `src/components/Header.tsx` | new-files batch |
| `src/components/HomePage.tsx` | new-files batch |
| `src/components/MovingChecklist.tsx` | new-files batch |
| `src/components/MyBookings.tsx` | new-files batch |
| `src/components/SubscriptionPlans.tsx` | new-files batch |
| `src/components/VanGuide.tsx` | new-files batch |
| `src/components/DriverPortal.tsx` | new-files batch |

### 4. Run locally

```bash
npm run dev
```

Open [http://localhost:8080](http://localhost:8080)

---

## Deploy to Vercel

### Option A — GitHub Import (recommended)

1. Push to GitHub:
   ```bash
   git add .
   git commit -m "Initial FlyttGo deployment"
   git push origin main
   ```

2. Go to [vercel.com](https://vercel.com) → **New Project** → Import your repo

3. Add environment variables in Vercel project settings:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_GOOGLE_MAPS_API_KEY`

4. Click **Deploy** — done in ~60 seconds

### Option B — Vercel CLI

```bash
npm i -g vercel
vercel login
vercel --prod
```

### After deploying — Supabase setup

In your Supabase Dashboard → **Authentication → URL Configuration**, add:
- Site URL: `https://your-project.vercel.app`
- Redirect URLs: `https://your-project.vercel.app/**`

---

## Project Structure

```
src/
├── components/
│   ├── ui/                  # shadcn/ui components
│   ├── AdminDashboard.tsx   # Full admin control panel
│   ├── AppLayout.tsx        # SPA router with lazy loading
│   ├── AuthModal.tsx        # Sign in / sign up modal
│   ├── BookingFlow.tsx      # 6-step booking with Kartverket autocomplete
│   ├── CustomerDashboard.tsx
│   ├── DriverOnboarding.tsx # 4-step driver application
│   ├── DriverPortal.tsx     # Jobs, wallet, subscriptions
│   ├── Footer.tsx           # With marketplace disclaimer
│   ├── Header.tsx           # Sticky nav with auth
│   ├── HomePage.tsx         # Hero, booking widget, sections
│   ├── LegalAcceptance.tsx  # Booking + driver checkboxes
│   ├── MovingChecklist.tsx
│   ├── MyBookings.tsx
│   ├── NorwayAddressAutocomplete.tsx  # Kartverket API
│   ├── SubscriptionPlans.tsx
│   └── VanGuide.tsx
├── lib/
│   ├── auth.ts              # Supabase auth context
│   ├── constants.ts         # Van types, pricing, inventory
│   ├── seoData.ts           # 12 cities × 8 services SEO engine
│   ├── store.ts             # App state (currentPage, bookingData)
│   └── supabase.ts          # Supabase client (reads from env vars)
├── pages/
│   ├── TermsPage.tsx        # Full T&C (13 sections)
│   ├── PrivacyPage.tsx      # GDPR-compliant privacy policy
│   ├── LiabilityPage.tsx    # Liability & insurance policy
│   ├── DriverTermsPage.tsx  # Driver agreement
│   └── SEOServiceCityPage.tsx  # Programmatic SEO template
└── utils/
    └── formatNorwegianAddress.ts  # Norwegian address formatting
```

---

## Key Features

- **Kartverket address autocomplete** — Official Norwegian address registry
- **Structured address storage** — 12 fields per address (street, postcode, city, lat/lng)
- **Escrow payment system** — Stripe + Vipps, funds held until delivery confirmed
- **Legal compliance** — Marketplace-only liability, GDPR privacy, full driver agreement
- **96 programmatic SEO pages** — 12 cities × 8 services, auto-generated with schema markup
- **Admin dashboard** — Real-time Supabase subscriptions, 7 tabs, escrow engine
- **Driver subscription system** — 5 plans, proration engine, expiry enforcement

---

## Legal

FlyttGo is a marketplace platform only. It does not transport goods and provides no insurance.
All liability rests with the Transport Provider's registered company.

© 2026 FlyttGo AS · Oslo, Norway · legal@flyttgo.com
