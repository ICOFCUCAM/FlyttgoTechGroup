import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../lib/auth';
import { useApp, Page } from '../lib/store';

export default function Header() {
  const { profile, signOut, user } = useAuth();
  const { setPage, setShowAuthModal, setAuthMode, currentPage } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [companiesOpen, setCompaniesOpen] = useState(false);
  const [lang, setLang] = useState<'EN' | 'NO'>('EN');
  const [langOpen, setLangOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const navItems: { label: string; page: Page }[] = [
    { label: 'Home',    page: 'home' },
    { label: 'Drivers', page: 'driver-onboarding' },
  ];

  const handleNav = (page: Page) => {
    setPage(page);
    setMobileOpen(false);
    setUserMenuOpen(false);
    setCompaniesOpen(false);
  };

  const corporateLinks = [
    { label: 'Bulk Booking Management',    desc: 'Multi-location deliveries at scale',    page: 'van-guide' as Page },
    { label: 'Recurring Deliveries',       desc: 'Daily, weekly or monthly scheduling',   page: 'van-guide' as Page },
    { label: 'Company Dashboard',          desc: 'Track spending & delivery performance',  page: 'customer-dashboard' as Page },
    { label: 'Invoice & Billing',          desc: 'Consolidated monthly invoices',          page: 'my-bookings' as Page },
    { label: 'Corporate API Access',       desc: 'Integrate FlyttGo into your systems',   page: 'van-guide' as Page },
  ];

  return (
    <header className="sticky top-0 z-40 shadow-md">
      {/* TOP BAR */}
      <div className="bg-[#1A365D] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-9 text-xs">
            <div className="flex items-center gap-4">
              <a href="tel:+4474321124438" className="flex items-center gap-1.5 text-white/80 hover:text-white transition">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                </svg>
                +44 7432 112438
              </a>
              <span className="text-white/30 hidden sm:block">|</span>
              <span className="text-white/70 hidden sm:block">Smart Moving &amp; Transport Services</span>
            </div>
            <div className="relative" ref={langRef}>
              <button onClick={() => setLangOpen(!langOpen)} className="flex items-center gap-1 text-white/70 hover:text-white transition text-xs">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064"/>
                </svg>
                {lang}
                <svg className={`w-3 h-3 ml-0.5 transition-transform ${langOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/>
                </svg>
              </button>
              {langOpen && (
                <div className="absolute right-0 top-full mt-2 w-28 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50">
                  {(['EN', 'NO'] as const).map(l => (
                    <button key={l} onClick={() => { setLang(l); setLangOpen(false); }}
                      className={`w-full text-left px-4 py-2 text-sm transition ${lang === l ? 'text-emerald-600 font-semibold bg-emerald-50' : 'text-gray-700 hover:bg-gray-50'}`}>
                      {l === 'EN' ? '🇬🇧 English' : '🇳🇴 Norsk'}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* MAIN NAV */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button onClick={() => handleNav('home')} className="flex items-center gap-2.5 group flex-shrink-0">
              <div className="w-9 h-9 bg-emerald-600 rounded-lg flex items-center justify-center shadow-sm">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2-1 2 1 2-1 2 1 2-1zm0 0l2 1 2-1 2 1V6a1 1 0 00-1-1h-4"/>
                </svg>
              </div>
              <span className="text-xl font-bold text-gray-900">Flytt<span className="text-emerald-600">Go</span></span>
            </button>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map(item => (
                <button key={item.page} onClick={() => handleNav(item.page)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${currentPage === item.page ? 'text-emerald-600 bg-emerald-50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}`}>
                  {item.label}
                </button>
              ))}

              {/* Companies dropdown */}
              <div className="relative">
                <button
                  onClick={() => { setUserMenuOpen(false); setLangOpen(false); setCompaniesOpen(prev => !prev); }}
                  onBlur={() => setTimeout(() => setCompaniesOpen(false), 150)}
                  className={`flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium transition ${companiesOpen ? 'text-emerald-600 bg-emerald-50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}`}>
                  Companies
                  <svg className={`w-4 h-4 transition-transform ${companiesOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/>
                  </svg>
                </button>
                {companiesOpen && (
                  <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-gray-100 py-3 z-50">
                    <div className="px-4 pb-2 border-b border-gray-100 mb-2">
                      <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Corporate Logistics Portal</p>
                    </div>
                    {corporateLinks.map(link => (
                      <button key={link.label} onClick={() => handleNav(link.page)}
                        className="w-full text-left px-4 py-3 hover:bg-emerald-50 transition group">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 group-hover:bg-emerald-600 transition">
                            <svg className="w-4 h-4 text-emerald-600 group-hover:text-white transition" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/>
                            </svg>
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-gray-800 group-hover:text-emerald-700">{link.label}</div>
                            <div className="text-xs text-gray-500 mt-0.5">{link.desc}</div>
                          </div>
                        </div>
                      </button>
                    ))}
                    <div className="px-4 pt-2 border-t border-gray-100 mt-2">
                      <button onClick={() => { setAuthMode('signup'); setShowAuthModal(true); setCompaniesOpen(false); }}
                        className="w-full py-2.5 bg-[#1A365D] text-white rounded-xl text-sm font-semibold hover:bg-[#2D4A7A] transition">
                        Create Corporate Account →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Right side */}
            <div className="flex items-center gap-2">
              <button onClick={() => handleNav('van-guide')}
                className="hidden sm:flex items-center gap-1.5 px-4 py-2 border border-emerald-600 text-emerald-600 rounded-lg text-sm font-semibold hover:bg-emerald-50 transition">
                Van Calculator
              </button>
              <button onClick={() => handleNav('booking')}
                className="hidden sm:flex items-center gap-1.5 px-5 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold hover:bg-emerald-700 transition shadow-sm">
                Book Now
              </button>

              {user && profile ? (
                <div className="relative">
                  <button onClick={() => { setCompaniesOpen(false); setLangOpen(false); setUserMenuOpen(prev => !prev); }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-gray-50 transition">
                    <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-semibold text-sm flex-shrink-0">
                      {(profile.first_name?.[0] || 'U').toUpperCase()}
                    </div>
                    <span className="hidden sm:block text-sm font-medium text-gray-700">
                      {profile.role === 'admin' ? 'FLYTTGO' : profile.first_name || 'User'}
                    </span>
                    <svg className={`w-4 h-4 text-gray-400 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/>
                    </svg>
                  </button>
                  {userMenuOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="text-sm font-bold text-gray-900">
                          {profile.role === 'admin' ? 'FLYTTGO Dashboard' : `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || 'User'}
                        </p>
                        <p className="text-xs text-gray-500 capitalize mt-0.5">{profile.role}</p>
                      </div>
                      {profile.role === 'customer' && (
                        <>
                          <button onClick={() => { handleNav('customer-dashboard'); setUserMenuOpen(false); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition">Dashboard</button>
                          <button onClick={() => { handleNav('my-bookings'); setUserMenuOpen(false); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition">My Bookings</button>
                        </>
                      )}
                      {profile.role === 'driver' && (
                        <button onClick={() => { handleNav('driver-portal'); setUserMenuOpen(false); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition">Driver Portal</button>
                      )}
                      {profile.role === 'admin' && (
                        <button onClick={() => { handleNav('admin'); setUserMenuOpen(false); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition">Admin Dashboard</button>
                      )}
                      <hr className="my-1 border-gray-100"/>
                      <button onClick={() => { signOut(); setUserMenuOpen(false); setPage('home'); }} className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition font-medium">Sign Out</button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="hidden sm:flex items-center gap-2">
                  <button onClick={() => { setAuthMode('signin'); setShowAuthModal(true); }} className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition">Sign In</button>
                  <button onClick={() => { setAuthMode('signup'); setShowAuthModal(true); }} className="px-3 py-2 text-sm font-medium text-[#1A365D] border border-[#1A365D] rounded-lg hover:bg-[#1A365D] hover:text-white transition">Sign Up</button>
                </div>
              )}

              <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition">
                <svg className="w-6 h-6 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {mobileOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/>}
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* MOBILE MENU */}
        {mobileOpen && (
          <div className="md:hidden border-t border-gray-100 bg-white pb-4">
            <div className="max-w-7xl mx-auto px-4 pt-3 space-y-1">
              {navItems.map(item => (
                <button key={item.page} onClick={() => handleNav(item.page)}
                  className={`block w-full text-left px-4 py-2.5 text-sm font-medium rounded-lg transition ${currentPage === item.page ? 'bg-emerald-50 text-emerald-700' : 'text-gray-700 hover:bg-gray-50'}`}>
                  {item.label}
                </button>
              ))}
              <div className="px-4 pt-1 pb-1">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Companies</p>
                {corporateLinks.map(link => (
                  <button key={link.label} onClick={() => handleNav(link.page)}
                    className="block w-full text-left px-2 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-700 rounded-lg transition">
                    {link.label}
                  </button>
                ))}
              </div>
              <button onClick={() => handleNav('van-guide')} className="block w-full text-left px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-lg">Van Calculator</button>
              <button onClick={() => { setAuthMode('driver-signup'); setShowAuthModal(true); setMobileOpen(false); }} className="block w-full text-left px-4 py-2.5 text-sm font-medium text-emerald-600 hover:bg-emerald-50 rounded-lg">Become a Driver</button>
              {!user && (
                <div className="flex gap-2 pt-2 px-4">
                  <button onClick={() => { setAuthMode('signin'); setShowAuthModal(true); setMobileOpen(false); }} className="flex-1 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700">Sign In</button>
                  <button onClick={() => handleNav('booking')} className="flex-1 py-2.5 bg-emerald-600 text-white rounded-lg text-sm font-semibold">Book Now</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
