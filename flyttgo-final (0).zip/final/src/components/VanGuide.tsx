import React, { useState } from 'react';
import { VAN_TYPES, recommendVan, INVENTORY_ITEMS } from '../lib/constants';
import { useApp } from '../lib/store';

export default function VanGuide() {
  const { setPage } = useApp();
  const [selected, setSelected] = useState('medium_van');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-emerald-700 to-emerald-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Van Size Guide & Calculator</h1>
          <p className="text-emerald-100 max-w-2xl mx-auto">Compare van sizes and find the perfect vehicle for your move.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {VAN_TYPES.map(van => (
            <div key={van.id}
              onClick={() => setSelected(van.id)}
              className={`bg-white rounded-2xl overflow-hidden border-2 cursor-pointer transition-all ${selected === van.id ? 'border-emerald-500 shadow-xl' : 'border-gray-100 hover:border-gray-300'}`}>
              <div className="aspect-[4/3] overflow-hidden">
                <img src={van.image} alt={van.name} className="w-full h-full object-cover" />
              </div>
              <div className="p-5">
                <h3 className="text-lg font-bold text-gray-900 mb-1">{van.name}</h3>
                <p className="text-sm text-emerald-600 font-medium mb-2">{van.capacity} · {van.payload}</p>
                <p className="text-sm text-gray-500 mb-3">Best for: {van.bestFor.slice(0, 2).join(', ')}</p>
                <p className="text-lg font-bold text-gray-900">From {van.pricePerHour} NOK/hr</p>
                <button onClick={() => setPage('booking')}
                  className="w-full mt-3 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition">
                  Book This Van
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
