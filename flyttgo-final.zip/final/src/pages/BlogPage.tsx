import React, { useState } from 'react';
import { useApp } from '../lib/store';

const POSTS = [
  {
    title: 'Complete Guide to Moving in Norway',
    excerpt: 'Everything you need to know about planning your move in Norway — from packing tips to choosing the right transport service.',
    category: 'Moving Guide', author: 'FlyttGo Team', date: 'Mar 5, 2026', readTime: '8 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059130758_7501de36.jpg',
    tags: ['Planning', 'Norway', 'Tips'], featured: true,
  },
  {
    title: 'How to Pack Furniture for Transport',
    excerpt: 'Professional tips for wrapping and protecting your furniture during a move. Avoid damage with expert techniques.',
    category: 'Packing Tips', author: 'FlyttGo Team', date: 'Mar 1, 2026', readTime: '5 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059179222_2daed41c.png',
    tags: ['Packing', 'Furniture'], featured: false,
  },
  {
    title: 'Moving Cost Guide: What to Expect in 2026',
    excerpt: 'A detailed breakdown of moving costs in Norway. Compare prices for different service levels and plan your budget.',
    category: 'Pricing', author: 'FlyttGo Team', date: 'Feb 25, 2026', readTime: '6 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059153486_c68ea67f.png',
    tags: ['Budget', 'Pricing', '2026'], featured: false,
  },
  {
    title: 'Top 10 Moving Mistakes to Avoid',
    excerpt: 'Learn from others experiences and make your next move stress-free and damage-free.',
    category: 'Moving Tips', author: 'FlyttGo Team', date: 'Feb 20, 2026', readTime: '4 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059182751_c6ff33d0.png',
    tags: ['Mistakes', 'Tips'], featured: false,
  },
  {
    title: 'Student Moving Guide: Budget-Friendly Tips',
    excerpt: 'Moving as a student? The best ways to save money while ensuring a smooth move.',
    category: 'Student Moving', author: 'FlyttGo Team', date: 'Feb 15, 2026', readTime: '5 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059178301_1fa0808b.png',
    tags: ['Student', 'Budget'], featured: false,
  },
  {
    title: "How FlyttGo's AI Dispatch Works",
    excerpt: 'A behind-the-scenes look at how our AI matches you with the perfect driver in under 30 seconds.',
    category: 'Technology', author: 'FlyttGo Team', date: 'Feb 10, 2026', readTime: '7 min read',
    image: 'https://d64gsuwffb70l.cloudfront.net/69aebba0474664f5e219add9_1773059247855_ab941e67.png',
    tags: ['AI', 'Technology'], featured: false,
  },
];

const CATS = ['All', 'Moving Guide', 'Packing Tips', 'Pricing', 'Moving Tips', 'Student Moving', 'Technology'];

const CATEGORY_COLORS: Record<string, string> = {
  'Moving Guide': 'bg-blue-100 text-blue-700',
  'Packing Tips': 'bg-emerald-100 text-emerald-700',
  'Pricing': 'bg-amber-100 text-amber-700',
  'Moving Tips': 'bg-purple-100 text-purple-700',
  'Student Moving': 'bg-pink-100 text-pink-700',
  'Technology': 'bg-cyan-100 text-cyan-700',
};

export default function BlogPage() {
  const { setPage } = useApp();
  const [activeCat, setActiveCat] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = POSTS.filter(p =>
    (activeCat === 'All' || p.category === activeCat) &&
    (p.title.toLowerCase().includes(search.toLowerCase()) || p.excerpt.toLowerCase().includes(search.toLowerCase()))
  );
  const featured = POSTS.find(p => p.featured);
  const grid = filtered.filter(p => !p.featured || activeCat !== 'All' || search);

  return (
    <div className="min-h-screen bg-white">

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0B2E59] to-[#1a4a8a] py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 text-white/70 text-xs px-4 py-2 rounded-full mb-6">
            ✍️ Expert Moving Guides & Tips
          </div>
          <h1 className="text-5xl font-extrabold text-white mb-4">Moving Blog</h1>
          <p className="text-white/60 text-lg mb-8 max-w-xl mx-auto">
            Expert advice, packing guides, pricing breakdowns, and industry insights for your next move.
          </p>
          <div className="relative max-w-md mx-auto">
            <span className="absolute left-4 top-3.5 text-gray-400">🔍</span>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search articles..."
              className="w-full pl-10 pr-4 py-3.5 rounded-xl text-sm shadow-lg focus:ring-2 focus:ring-[#F2B705] outline-none"
            />
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <div className="sticky top-16 z-30 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex gap-2 overflow-x-auto">
          {CATS.map(cat => (
            <button key={cat} onClick={() => setActiveCat(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition ${
                activeCat === cat ? 'bg-[#0B2E59] text-white shadow-sm' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}>
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        {/* FEATURED */}
        {featured && activeCat === 'All' && !search && (
          <div className="mb-12 group cursor-pointer">
            <div className="relative bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-lg hover:shadow-2xl transition-all duration-300">
              <div className="grid lg:grid-cols-5">
                <div className="lg:col-span-2 h-72 lg:h-auto overflow-hidden">
                  <img src={featured.image} alt={featured.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                </div>
                <div className="lg:col-span-3 p-8 lg:p-10 flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="px-3 py-1 bg-[#F2B705] text-[#0B2E59] text-xs font-bold rounded-full">⭐ Featured</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${CATEGORY_COLORS[featured.category]}`}>{featured.category}</span>
                  </div>
                  <h2 className="text-3xl font-extrabold text-[#0B2E59] mb-3 group-hover:text-[#F2B705] transition-colors leading-tight">{featured.title}</h2>
                  <p className="text-gray-600 text-base mb-5 leading-relaxed">{featured.excerpt}</p>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {featured.tags.map(t => (
                      <span key={t} className="px-2.5 py-1 bg-gray-100 text-gray-500 text-xs rounded-full">#{t}</span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-sm text-gray-400">
                      <span>✍️ {featured.author}</span>
                      <span>·</span>
                      <span>⏱ {featured.readTime}</span>
                      <span>·</span>
                      <span>{featured.date}</span>
                    </div>
                    <button className="flex items-center gap-2 text-[#0B2E59] font-bold text-sm group-hover:gap-3 transition-all">
                      Read More <span>→</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* GRID */}
        {grid.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {grid.map(post => (
              <article key={post.title} className="group cursor-pointer bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="h-48 overflow-hidden relative">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"/>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"/>
                  <span className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold ${CATEGORY_COLORS[post.category]}`}>
                    {post.category}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="text-base font-bold text-[#0B2E59] mb-2 group-hover:text-[#F2B705] transition-colors line-clamp-2 leading-snug">{post.title}</h3>
                  <p className="text-gray-500 text-sm mb-3 line-clamp-2 leading-relaxed">{post.excerpt}</p>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {post.tags.map(t => (
                      <span key={t} className="text-xs text-gray-400 bg-gray-50 px-2 py-0.5 rounded-full">#{t}</span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-gray-50">
                    <span>{post.date}</span>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-300"/>
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="text-4xl mb-3">📭</div>
            <h3 className="font-bold text-gray-700 mb-1">No articles found</h3>
            <p className="text-gray-400 text-sm">Try a different search or category.</p>
          </div>
        )}

        {/* NEWSLETTER */}
        <div className="mt-16 bg-gradient-to-br from-[#0B2E59] to-[#1a4a8a] rounded-3xl p-10 text-center">
          <div className="text-4xl mb-4">📬</div>
          <h3 className="text-2xl font-extrabold text-white mb-2">Get Moving Tips in Your Inbox</h3>
          <p className="text-white/60 mb-6 max-w-sm mx-auto text-sm">Join 12,000+ Norwegians who get our best moving advice every month.</p>
          <div className="flex gap-2 max-w-sm mx-auto">
            <input placeholder="Your email address" className="flex-1 px-4 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#F2B705]"/>
            <button className="px-5 py-3 bg-[#F2B705] text-[#0B2E59] font-bold rounded-xl text-sm hover:bg-[#F2B705]/90 transition whitespace-nowrap">Subscribe</button>
          </div>
          <p className="text-white/30 text-xs mt-3">No spam. Unsubscribe anytime.</p>
        </div>
      </div>

      {/* CTA */}
      <section className="bg-gray-50 py-12 border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-extrabold text-[#0B2E59] mb-3">Ready to Book Your Move?</h3>
          <p className="text-gray-500 mb-6">Join 25,000+ customers who've moved with FlyttGo across Norway.</p>
          <button onClick={() => setPage('booking')}
            className="px-10 py-4 bg-emerald-600 text-white rounded-xl font-bold text-base hover:bg-emerald-700 transition shadow-lg">
            Get Instant Price →
          </button>
        </div>
      </section>
    </div>
  );
}
