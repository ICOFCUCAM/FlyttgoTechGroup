import React, { useState, useEffect } from 'react';

interface CookiePrefs { necessary: boolean; analytics: boolean; marketing: boolean; functional: boolean; }

const DEFAULT_PREFS: CookiePrefs = { necessary: true, analytics: false, marketing: false, functional: false };

export function useCookieConsent() {
  const stored = typeof window !== 'undefined' ? localStorage.getItem('cookie_consent') : null;
  return stored ? JSON.parse(stored) as CookiePrefs : null;
}

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [prefs, setPrefs] = useState<CookiePrefs>(DEFAULT_PREFS);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('cookie_consent');
    if (!stored) setTimeout(() => setVisible(true), 1200);
  }, []);

  function accept(all: boolean) {
    const p = all ? { necessary: true, analytics: true, marketing: true, functional: true } : prefs;
    localStorage.setItem('cookie_consent', JSON.stringify(p));
    localStorage.setItem('cookie_consent_date', new Date().toISOString());
    setSaved(true);
    setTimeout(() => setVisible(false), 600);
  }

  function toggle(key: keyof CookiePrefs) {
    if (key === 'necessary') return;
    setPrefs(p => ({ ...p, [key]: !p[key] }));
  }

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] p-4 sm:p-6">
      <div className={`max-w-2xl mx-auto bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden transition-all duration-300 ${saved ? 'opacity-0 translate-y-4' : 'opacity-100'}`}>

        {/* Main banner */}
        {!showDetails && (
          <div className="p-6">
            <div className="flex items-start gap-4">
              <div className="text-3xl flex-shrink-0">🍪</div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-900 mb-1.5">We use cookies</h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-4">
                  FlyttGo uses cookies to improve your experience, analyse site usage, and show relevant content.
                  We respect your privacy and comply with GDPR and the Norwegian Personal Data Act.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => accept(true)}
                    className="px-5 py-2.5 bg-[#0B2E59] text-white text-sm font-bold rounded-xl hover:bg-[#1a4a8a] transition">
                    Accept All
                  </button>
                  <button onClick={() => accept(false)}
                    className="px-5 py-2.5 bg-gray-100 text-gray-700 text-sm font-semibold rounded-xl hover:bg-gray-200 transition">
                    Necessary Only
                  </button>
                  <button onClick={() => setShowDetails(true)}
                    className="px-5 py-2.5 border border-gray-200 text-gray-600 text-sm font-medium rounded-xl hover:bg-gray-50 transition">
                    Manage Preferences
                  </button>
                </div>
              </div>
              <button onClick={() => accept(false)} className="text-gray-400 hover:text-gray-600 flex-shrink-0 text-xl leading-none">×</button>
            </div>
          </div>
        )}

        {/* Detailed preferences */}
        {showDetails && (
          <div className="p-6">
            <div className="flex items-center gap-3 mb-5">
              <button onClick={() => setShowDetails(false)} className="text-gray-400 hover:text-gray-600 text-lg">←</button>
              <h3 className="font-bold text-gray-900">Cookie Preferences</h3>
            </div>

            <div className="space-y-3 mb-5">
              {([
                { key: 'necessary', title: 'Strictly Necessary', desc: 'Authentication, session management, and security. Cannot be disabled.', locked: true },
                { key: 'functional', title: 'Functional', desc: 'Remember your preferences, saved addresses, and language settings.', locked: false },
                { key: 'analytics', title: 'Analytics', desc: 'Understand how visitors interact with FlyttGo to improve the platform.', locked: false },
                { key: 'marketing', title: 'Marketing', desc: 'Show relevant advertisements on third-party platforms.', locked: false },
              ] as { key: keyof CookiePrefs; title: string; desc: string; locked: boolean }[]).map(item => (
                <div key={item.key} className="flex items-center justify-between gap-4 bg-gray-50 rounded-xl px-4 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-semibold text-gray-900">{item.title}</span>
                      {item.locked && <span className="text-xs bg-gray-200 text-gray-500 px-2 py-0.5 rounded-full">Required</span>}
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
                  </div>
                  <button
                    onClick={() => toggle(item.key)}
                    disabled={item.locked}
                    className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${
                      prefs[item.key] ? 'bg-[#0B2E59]' : 'bg-gray-300'
                    } ${item.locked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${prefs[item.key] ? 'translate-x-5' : ''}`}/>
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <button onClick={() => accept(false)}
                className="flex-1 py-2.5 bg-[#0B2E59] text-white text-sm font-bold rounded-xl hover:bg-[#1a4a8a] transition">
                Save Preferences
              </button>
              <button onClick={() => accept(true)}
                className="flex-1 py-2.5 bg-gray-100 text-gray-700 text-sm font-semibold rounded-xl hover:bg-gray-200 transition">
                Accept All
              </button>
            </div>

            <p className="text-xs text-gray-400 text-center mt-3">
              Your preferences are stored locally. See our <button className="underline hover:text-gray-600">Privacy Policy</button> for details.
              Compliant with GDPR · Norwegian Personopplysningsloven.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
