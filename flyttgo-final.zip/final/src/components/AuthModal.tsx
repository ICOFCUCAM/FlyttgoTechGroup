import React, { useState } from "react";
import { useApp } from "../lib/store";
import { useAuth } from "../lib/auth";
import { X, Eye, EyeOff } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

export default function AuthModal() {
  const { showAuthModal, setShowAuthModal, authMode, setAuthMode } = useApp();
  const { signIn, signUp } = useAuth();
  const { t } = useLanguage();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (!showAuthModal) return null;

  const isSignIn = authMode === "signin";
  const isDriverSignup = authMode === "driver-signup";
  const isCorporateSignup = authMode === "corporate-signup";
  const isAdminLogin = authMode === "admin-login";

  const role =
    isDriverSignup
      ? "driver"
      : isCorporateSignup
      ? "corporate"
      : "customer";

  async function handleGoogleSignIn() {
    const { supabase } = await import("../lib/supabase");

    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: window.location.origin,
      },
    });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isSignIn || isAdminLogin) {
        const { error } = await signIn(email, password);

        if (error) {
          setError(error.message);
          return;
        }
      } else {
        const { error } = await signUp(
          email,
          password,
          firstName,
          lastName,
          role
        );

        if (error) {
          setError(error.message);
          return;
        }
      }

      setShowAuthModal(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 relative">

        {/* Close button */}
        <button
          onClick={() => setShowAuthModal(false)}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-3">
            <span className="text-2xl">
              {isSignIn
                ? "👋"
                : isDriverSignup
                ? "🚐"
                : isCorporateSignup
                ? "🏢"
                : "✨"}
            </span>
          </div>

          <h2 className="text-2xl font-bold text-gray-900">
            {isSignIn
              ? "Welcome back"
              : isDriverSignup
              ? "Become a Driver"
              : isCorporateSignup
              ? "Create Corporate Account"
              : "Create account"}
          </h2>

          <p className="text-gray-500 text-sm mt-1">
            {isSignIn
              ? "Sign in to your FlyttGo account"
              : isDriverSignup
              ? "Start earning with FlyttGo"
              : isCorporateSignup
              ? "Register your company with FlyttGo"
              : "Join FlyttGo today — it's free"}
          </p>
        </div>

        {/* Google login */}
        <button
          onClick={handleGoogleSignIn}
          className="w-full flex items-center justify-center gap-2 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition mb-4"
        >
          <img
            src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
            className="w-4 h-4"
          />
          Continue with Google
        </button>

        {/* Divider */}
        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200" />
          </div>

          <div className="relative flex justify-center text-xs">
            <span className="bg-white px-2 text-gray-400">or</span>
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 rounded-xl p-3 text-sm mb-4">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">

          {!isSignIn && (
            <div className="grid grid-cols-2 gap-3">

              <input
                placeholder="First name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
                className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm"
              />

              <input
                placeholder="Last name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
                className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm"
              />

            </div>
          )}

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm"
          />

          <div className="relative">

            <input
              type={showPass ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm pr-10"
            />

            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>

          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition"
          >
            {loading
              ? "Please wait..."
              : isSignIn
              ? "Sign In"
              : isDriverSignup
              ? "Apply as Driver"
              : isCorporateSignup
              ? "Register Company"
              : "Create Account"}
          </button>

        </form>

        {/* Switch mode */}
        <p className="text-center text-sm text-gray-500 mt-4">

          {isSignIn ? (
            <>
              Don't have an account?{" "}
              <button
                onClick={() => setAuthMode("signup")}
                className="text-emerald-600 font-semibold hover:underline"
              >
                Sign up
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button
                onClick={() => setAuthMode("signin")}
                className="text-emerald-600 font-semibold hover:underline"
              >
                Sign in
              </button>
            </>
          )}

        </p>
      </div>
    </div>
  );
}
