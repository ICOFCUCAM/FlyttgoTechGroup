import React from 'react';
import { useApp } from '../lib/store';

export default function RecurringDeliveriesPage() {
  const { setPage, setShowAuthModal, setAuthMode } = useApp();

  return (
    <div className="min-h-screen bg-white">

      
      <section className="bg-gradient-to-br from-[#0B2E59] to-[#1a4a8a] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 text-white/80 text-xs font-medium px-4 py-2 rounded-full mb-6">🔁 Automation · Scheduled Logistics</div>
          <h1 className="text-5xl font-extrabold mb-4 leading-tight">Recurring Delivery Schedules</h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto mb-8">Set up daily, weekly, or monthly delivery runs that execute automatically — no manual rebooking, no missed pickups.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => { setShowAuthModal(true); setAuthMode('signup'); }}
              className="px-10 py-4 bg-[#F2B705] text-[#0B2E59] rounded-xl font-bold text-base hover:bg-[#F2B705]/90 transition shadow-lg">
              Get Started Free →
            </button>
            <button onClick={() => setPage('corporate-dashboard')}
              className="px-10 py-4 bg-white/10 text-white rounded-xl font-semibold text-base hover:bg-white/20 transition">
              View Dashboard Demo
            </button>
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-extrabold text-[#0B2E59] text-center mb-3">Why Recurring Delivery Schedules</h2>
        <p className="text-gray-500 text-center mb-12 max-w-xl mx-auto">Enterprise-grade logistics capabilities built for scale.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">📅</div>
            <h3 className="font-bold text-gray-900 mb-2">Schedule Once, Run Forever</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Define your delivery schedule and it runs automatically — daily, weekly, or custom intervals.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">🔔</div>
            <h3 className="font-bold text-gray-900 mb-2">Smart Notifications</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Automated alerts for upcoming deliveries, driver assignments, and completion confirmations.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">🛑</div>
            <h3 className="font-bold text-gray-900 mb-2">Pause & Resume</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Instantly pause any schedule without losing your configuration. Resume with one click.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">🔄</div>
            <h3 className="font-bold text-gray-900 mb-2">Dynamic Rescheduling</h3>
            <p className="text-gray-500 text-sm leading-relaxed">AI detects conflicts and proposes alternatives before they become missed deliveries.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">📈</div>
            <h3 className="font-bold text-gray-900 mb-2">Pattern Analytics</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Understand your delivery patterns to optimize routes, timing, and driver allocation.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition">
            <div className="text-3xl mb-3">🤝</div>
            <h3 className="font-bold text-gray-900 mb-2">Dedicated Drivers</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Assign preferred drivers to recurring routes for service consistency.</p>
          </div>
        </div>
      </section>

      {/* WORKFLOW */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-3xl font-extrabold text-[#0B2E59] text-center mb-12">How It Works</h2>
          <div className="grid sm:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-10 h-10 bg-[#0B2E59] text-white rounded-full flex items-center justify-center text-lg font-bold mx-auto mb-3">1</div>
              <h3 className="font-bold text-gray-900 text-sm mb-1">Define Schedule</h3>
              <p className="text-gray-500 text-xs">Set pickup and delivery addresses, frequency, time windows, and cargo requirements.</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-[#0B2E59] text-white rounded-full flex items-center justify-center text-lg font-bold mx-auto mb-3">2</div>
              <h3 className="font-bold text-gray-900 text-sm mb-1">Assign Drivers</h3>
              <p className="text-gray-500 text-xs">Choose preferred drivers or let automatic matching handle allocation.</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-[#0B2E59] text-white rounded-full flex items-center justify-center text-lg font-bold mx-auto mb-3">3</div>
              <h3 className="font-bold text-gray-900 text-sm mb-1">Automate</h3>
              <p className="text-gray-500 text-xs">The schedule runs without manual intervention. Exceptions are flagged automatically.</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-[#0B2E59] text-white rounded-full flex items-center justify-center text-lg font-bold mx-auto mb-3">4</div>
              <h3 className="font-bold text-gray-900 text-sm mb-1">Review & Optimize</h3>
              <p className="text-gray-500 text-xs">Monthly analytics reports highlight optimization opportunities.</p>
            </div>
          </div>
        </div>
      </section>

      {/* USE CASES */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h2 className="text-2xl font-extrabold text-[#0B2E59] mb-3">Industries & Use Cases</h2>
        <p className="text-gray-500 mb-8">Trusted by operations teams across Norway.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Daily newspaper distribution</span>
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Weekly restaurant supply runs</span>
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Monthly office supplies</span>
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Construction site deliveries</span>
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Retail replenishment</span>
          <span className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700">Medical supply chains</span>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-[#0B2E59] to-[#1a4a8a] py-16">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-extrabold text-white mb-4">Ready to Scale Your Logistics?</h2>
          <p className="text-white/70 mb-8">Join 500+ companies using FlyttGo Corporate across Norway.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => { setShowAuthModal(true); setAuthMode('signup'); }}
              className="px-10 py-4 bg-[#F2B705] text-[#0B2E59] rounded-xl font-bold text-base hover:bg-[#F2B705]/90 transition shadow-lg">
              Create Corporate Account
            </button>
            <button onClick={() => setPage('corporate')}
              className="px-10 py-4 bg-white/10 text-white rounded-xl font-semibold text-base hover:bg-white/20 transition">
              View All Plans
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
